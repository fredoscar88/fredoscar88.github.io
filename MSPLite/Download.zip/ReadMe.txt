MSPLite (name pending) Alpha 1.0-
MSPLite runs only on minecraft servers. Command blocks are
automatically placed into the world by communicating with the server.

How to use
**You will need the a snapshot (15w42a, not confirmed to work with the
latest, but it should) minecraft server jar file, and a pregenerated world**
	
	I- Running MSPLite	
		1. 	Place all of the files that came in the .zip folder into
			the same directory you put the server jar file in.
		
		2.	Rename the server jar file to "server.jar".
		
		3.	Double click "MSPRun" or "MSPRun.bat" to launch MSPLite.
			If you have done everything correctly it should start the server (it may take a moment)

			
	II- Writing the redstone text files
		1.	All redstone text files are stored in the Redstone directory.
			You must have the "main.txt" present to run. This file contains
			certain parameters for the system which are written in that file.
		
		2.	To start, you can create a new text file or start writing
			in the main.txt file. Every line (with some exceptions) is
			put into a command block, which executes in the order commands
			are listed in the file.
			
		3.	What's NOT read by the system command blocks:
				-Empty lines
				-Lines starting with "#", consider them comments
				-The first two lines in the main.txt file (reasoning in number 4)
		
		4.	main.txt stores information about the starting block and the pattern each file
			will follow in the first two lines. The numbers after "POS" are where the first
			repeating command block is, the numbers after "PAT" define the volume they
			fill. For now I reccommend leaving PAT alone, but changing POS to where you
			want your redstone.
		
		5.	You cannot name redstone text files the following:
			-"documentation.txt"
			-"NOTES.txt"	(case sensitive)
			-"replaces.txt"
			-output.txt
			And you should always have a "main.txt"
	
	
	III- Generating the redstone
		1.	If you're satisfied with your text files, save them.
			
		2. 	In the console that opened when you ran "MSPRun.bat", 
			enter in "MakeRedstone". The first time redstone is generated after 
			MSPLite is started may take a moment to work
			
**Lastly if you have any questions or you think this readme did a bad job let me know over skype! Thanks, -fredo**